temperature_output_04 = {'Kherson': {'AverageTemperatureFahr': 48.29304615384615},
 'Auckland': {'AverageTemperatureFahr': 57.87582285714286},
 'Kiev': {'AverageTemperatureFahr': 43.04894782608696},
 'Lvov': {'AverageTemperatureFahr': 43.50919999999999},
 'Marseille': {'AverageTemperatureFahr': 61.1707052631579},
 'Odesa': {'AverageTemperatureFahr': 52.084149999999994},
 'Paris': {'AverageTemperatureFahr': 44.5413875},
 'Stockholm': {'AverageTemperatureFahr': 42.46838461538461}}